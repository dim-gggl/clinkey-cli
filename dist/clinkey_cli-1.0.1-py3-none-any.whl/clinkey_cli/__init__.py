"""clinkey-cli package public API."""

from .main import Clinkey, clinkey

__all__ = ["Clinkey", "clinkey"]
__version__ = "1.0.1"
